from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="It is a wine quality prediction project",
    author="prabhat",
    packages=find_packages(),
    license="MIT",
    license_file="LICENSE"
)
